/*
Only there for registering ajax
Return null
*/